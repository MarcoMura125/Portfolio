import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set_2d, fourier_dict_2d, db_to_lin

SEED = 312
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 6000        # number of training samples
N_test = 20     # number of test samples

n = 64      # dimension of measurement vector y
M1, M2 = 12, 12   # dimension of 2D grid
m = M1 * M2       # total dimension of the sparse signal x
k = 4       # sparsity level (k-sparse signal)

T_LISTA = 5             # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 20 * T_LISTA   # number of iterations for ISTA and FISTA

### Construct 2D Fourier-based measurement matrix Phi ###
Psi = fourier_dict_2d(M1, M2)
random_indices = np.random.choice(m, n, replace=False)
omega = np.sort(random_indices)
R = torch.zeros((n,m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)

### Generate synthetic datasets (training & test) ###
train_loader = create_data_set_2d(Phi, n=n, M1=M1, M2=M2, k=k, N=N, noise_dev=np.sqrt(db_to_lin(-40)))
test_loader = create_data_set_2d(Phi, n=n, M1=M1, M2=M2, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-40)))

### Dictonary estimation ###
Y = train_loader.dataset.y.t()  # Y dataset paper notation [n x N]
X = train_loader.dataset.x.t()  # X dataset paper notation [m x N]
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H



### Apply the different methods ###
x_hat_ista , ista_mse_vs_iter = ista_apply(test_loader, T_ISTA, Phi, rho=0.05)
x_hat_fista , fista_mse_vs_iter = fista_apply(test_loader, T_ISTA, Phi, rho=0.05)
x_hat_lista, lista_mse_vs_iter, _ = lista_apply(train_loader, test_loader, T=T_LISTA, Phi= Phi_est)
x_hat_lista_toeplitz, lista_toeplitz_mse_vs_iter, _ = lista_toeplitz_apply(train_loader, test_loader, M1, M2, T=T_LISTA, Phi= Phi_est)



### Plot the results (NMSE vs iterations/layers) ###
fig = plt.figure()
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter, label='ISTA', color='b', linewidth=0.5)
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter, label='FISTA', color='r', linewidth=0.5)
plt.plot(range(T_LISTA + 1), lista_mse_vs_iter, label='LISTA', color='gold', linewidth=2)
plt.plot(range(T_LISTA + 1), lista_toeplitz_mse_vs_iter, label='LISTA_Toeplitz', color='purple', linewidth=2)
plt.title('NMSE vs Number of iterations/layers', fontsize=12)
plt.xlabel('Number of iteration/layer', fontsize=10)
plt.ylabel('NMSE', fontsize=10)
plt.yscale("log")
plt.legend()
plt.grid(True)
plt.show()



### Plot the results (Estimates vs true sparse signal) ###

# Parameter t
f1 = np.linspace(0, 1, M1)
f2 = np.linspace(0, 1, M2)

sample_idx = 8

# Ground truth (from dataset)
x_true_vec = test_loader.dataset.x[sample_idx, :]  
x_true_mat = x_true_vec.reshape(M1, M2)

# ISTA estimate
x_hat_ista_vec = x_hat_ista[sample_idx, :] 
x_hat_ista_mat = x_hat_ista_vec.reshape(M1, M2)

# FISTA estimate
x_hat_fista_vec = x_hat_fista[sample_idx, :]  
x_hat_fista_mat = x_hat_fista_vec.reshape(M1, M2)

# LISTA estimate
x_hat_lista_vec = x_hat_lista[sample_idx, :] 
x_hat_lista_mat = x_hat_lista_vec.reshape(M1, M2)

# LISTA Toeplitz estimate
x_hat_lista_toeplitz_vec = x_hat_lista_toeplitz[sample_idx, :]  
x_hat_lista_toeplitz_mat = x_hat_lista_toeplitz_vec.reshape(M1, M2)


# Create figure and 3D axes
fig = plt.figure()
ax = fig.add_subplot(111, projection='3d')

# Baseline
z_base = 0

first_time = 1

for i in range(M1):
    for j in range(M2):
        if np.abs(x_true_mat[i, j]) > 0.1:
            # Plot ground truth
            ax.plot([f1[i], f1[i]], [f2[j], f2[j]], [z_base, np.abs(x_true_mat[i, j])], color='black', linewidth=0.8)

            if first_time: 
                # ax.plot([f1[i]], [f2[j]], [np.abs(x_true_mat[i, j])], linestyle='none',
                #     marker='o', markerfacecolor='none', markeredgecolor='black', label = "Ground truth")
                ax.plot([f1[i]], [f2[j]], [np.abs(x_true_mat[i, j])], linestyle='none',
                    marker='o', markeredgecolor='black', label = "Ground truth")
                first_time = 0
            else:
                # ax.plot([f1[i]], [f2[j]], [np.abs(x_true_mat[i, j])], linestyle='none',
                #     marker='o', markerfacecolor='none', markeredgecolor='black')
                ax.plot([f1[i]], [f2[j]], [np.abs(x_true_mat[i, j])], linestyle='none',
                    marker='o', markeredgecolor='black')
        
first_time = 1

for i in range(M1):
    for j in range(M2):
        if np.abs(x_hat_ista_mat[i, j]) > 0.1:
            # Plot ISTA estimate
            ax.plot([f1[i], f1[i]], [f2[j], f2[j]], [z_base, np.abs(x_hat_ista_mat[i, j])], color='b', linewidth=0.8)

            if first_time:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_ista_mat[i, j])], linestyle='none',
                    marker='s', markerfacecolor='none', markeredgecolor='b', label = "ISTA") 
                first_time = 0
            
            else:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_ista_mat[i, j])], linestyle='none',
                    marker='s', markerfacecolor='none', markeredgecolor='b')

first_time = 1

for i in range(M1):
    for j in range(M2):
        if np.abs(x_hat_fista_mat[i, j]) > 0.1:
            # Plot FISTA estimate
            ax.plot([f1[i], f1[i]], [f2[j], f2[j]], [z_base, np.abs(x_hat_fista_mat[i, j])], color='r', linewidth=0.8)

            if first_time:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_fista_mat[i, j])], linestyle='none',
                    marker='^', markerfacecolor='none', markeredgecolor='r', label = "FISTA") 
                first_time = 0
            
            else:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_fista_mat[i, j])], linestyle='none',
                    marker='^', markerfacecolor='none', markeredgecolor='r')

first_time = 1

for i in range(M1):
    for j in range(M2):
        if np.abs(x_hat_lista_mat[i, j]) > 0.1:
            # Plot FISTA estimate
            ax.plot([f1[i], f1[i]], [f2[j], f2[j]], [z_base, np.abs(x_hat_lista_mat[i, j])], color='gold', linewidth=0.8)

            if first_time:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_lista_mat[i, j])], linestyle='none',
                    marker='D', markerfacecolor='none', markeredgecolor='gold', label = "LISTA") 
                first_time = 0
            else:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_lista_mat[i, j])], linestyle='none',
                    marker='D', markerfacecolor='none', markeredgecolor='gold') 
                
first_time = 1

for i in range(M1):
    for j in range(M2):
        if np.abs(x_hat_lista_toeplitz_mat[i, j]) > 0.1:
            # Plot FISTA estimate
            ax.plot([f1[i], f1[i]], [f2[j], f2[j]], [z_base, np.abs(x_hat_lista_toeplitz_mat[i, j])], color='gold', linewidth=0.8)

            if first_time:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_lista_toeplitz_mat[i, j])], linestyle='none',
                    marker='*', markerfacecolor='none', markeredgecolor='purple', label = "LISTA Toeplitz") 
                first_time = 0
            else:
                ax.plot([f1[i]], [f2[j]], [np.abs(x_hat_lista_toeplitz_mat[i, j])], linestyle='none',
                    marker='*', markerfacecolor='none', markeredgecolor='purple')

ax.set_xlim([1, 0])
ax.set_ylim([0, 1])
ax.set_xlabel("1st normalized frequency")
ax.set_ylabel("2nd normalized frequency")
ax.set_zlabel("amplitude")
ax.legend(loc="upper left")
ax.set_title("Figure 11")
plt.show()





