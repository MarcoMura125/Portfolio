This project is organized into several main executable files, each designed to be run independently.

Running one of these main files will produce specific figures of the "Structured LISTA for Multidimensional
Harmonic Retrieval" article.

In addition to the main executables, the project includes a collection of supporting modules and class definitions.

- The files ISTA.py, FISTA.py, LISTA.py and LISTA_Toeplitz.py implement the corresponding algorithms. They are imported by
  the main files. 

- The utils.py file contain several helper functions that are used by other files in the project.


It is recommended to create a virtual environment by typing in the terminal:
    python -m venv venv    # Windows
    python3 -m venv venv   # Linux / macOS

Then activate the environment:
    venv\Scripts\activate           # Windows (Command Prompt)
    .\venv\Scripts\Activate.ps1     # Windows (PowerShell)
    source venv/bin/activate        # Linux / macOS

At this point install the required packages by running:
    pip install -r requirements.txt
