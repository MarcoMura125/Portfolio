import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import train
from scipy.linalg import eigvalsh
import math

import time

# Lista Toeplitz Model
class LISTA_Toeplitz_Model(nn.Module):
    def __init__(self, n, M1, M2, T=6, lambd=0.02, Phi=None):
        super().__init__()
        
        self.n, self.m = n, M1 * M2
        self.M1, self.M2 = M1, M2
        self.T = T
        self.lambd = lambd

        # Layer lineari reali su vettori concatenati [Re, Im]
        self.We = nn.Linear(2*self.m, 2*n, bias=False)
        self.H = nn.Parameter(torch.zeros(2*(2*self.M1 - 1), 2*(2*self.M2 - 1)), requires_grad=True)

        L = float(eigvalsh(Phi.H @ Phi, eigvals=(self.m - 1, self.m - 1)))  # returns the max eigenvalue of: Phi.H @ Phi

        self.beta = nn.Parameter((lambd/L) * torch.ones(T + 1, 1, 1), requires_grad=True)


        if Phi is not None:
            # Construct the real block matrix for Phi
            Phi_r = Phi.real
            Phi_i = Phi.imag
            Phi_block = torch.cat([
                torch.cat([Phi_r, -Phi_i], dim=1),
                torch.cat([Phi_i,  Phi_r], dim=1)
            ], dim=0)

            # Initialize We
            self.We.weight.data = (1/L) * Phi_block.t()


    def _complex_soft_threshold(self, x, beta):
        # x: [batch, 2*m] (Re, Im)
        x_real, x_imag = x[:, :self.m], x[:, self.m:]
        mag = torch.sqrt(x_real**2 + x_imag**2 + 1e-12)
        scale = torch.clamp(1 - beta / (mag + 1e-12), min=0.0)
        x_real = x_real * scale
        x_imag = x_imag * scale
        return torch.cat([x_real, x_imag], dim=1)
    
    

    def _conv2d_full_fft(self, H, X):
        # H: (h1, h2), kernel complesso o reale
        # X: (batch, M1, M2), input complesso o reale
        # return: (batch, M1*M2*2) [Re, Im concatenati]

        dtype = X.dtype
        device = X.device

        batch, M1, M2 = X.shape
        h1, h2 = H.shape

        # full convolution size
        out1 = M1 + h1 - 1
        out2 = M2 + h2 - 1

        # choose fft size (padded)
        fft1 = int(2 ** math.ceil(math.log2(out1)))
        fft2 = int(2 ** math.ceil(math.log2(out2)))

        # pad H
        pad_H = torch.zeros((fft1, fft2), dtype=dtype, device=device)
        pad_H[:h1, :h2] = H

        # pad X batch-wise
        pad_X = torch.zeros((batch, fft1, fft2), dtype=dtype, device=device)
        pad_X[:, :M1, :M2] = X

        # FFT-based convolution
        if dtype == torch.complex128:
            FH = torch.fft.fft2(pad_H)                    # (fft1, fft2)
            FX = torch.fft.fft2(pad_X)                    # (batch, fft1, fft2)
            conv = torch.fft.ifft2(FX * FH[None, :, :])   # broadcast FH over batch
        else:
            FH = torch.fft.rfft2(pad_H)
            FX = torch.fft.rfft2(pad_X)
            conv = torch.fft.irfft2(FX * FH[None, :, :], s=(fft1, fft2))

        # crop to linear convolution size
        conv = conv[:, :out1, :out2]

        # extract the central block M1 x M2
        start_i = (conv.shape[1] - M1) // 2
        start_j = (conv.shape[2] - M2) // 2
        result = conv[:, start_i:start_i + M1, start_j:start_j + M2]  # (batch, M1, M2)

        # flatten e separate Re/Im
        result_re = result.real.reshape(batch, -1)
        result_im = result.imag.reshape(batch, -1)

        return torch.cat([result_re, result_im], dim=1)   # (batch, 2*M1*M2)


    
    def forward(self, y, x_gt=None, NMSE_flag=False):
        # y: [batch, n] complex -> [batch, 2*n] real
        # x_gt: [batch, m] complex
        y_cat = torch.cat([y.real, y.imag], dim=1)
        mse_vs_itr = []

        # Initialize x_hat
        x_hat = self._complex_soft_threshold(self.We(y_cat), self.beta[0])

        batch_size = y.shape[0]

        # Run the network
        for i in range(1, self.T + 1):

            x_hat_r = x_hat[:, :self.m]
            x_hat_i = x_hat[:, self.m:]

            X_r = x_hat_r.reshape(batch_size, self.M1, self.M2)
            X_i = x_hat_i.reshape(batch_size, self.M1, self.M2)

            X = torch.complex(X_r, X_i)

            H_r = self.H[:2*self.M1 - 1, :2*self.M2 - 1]
            H_i = self.H[2*self.M1 - 1:, :2*self.M2 - 1]

            H =torch.complex(H_r, H_i)

            x_hat = self._complex_soft_threshold(
                self._conv2d_full_fft(H, X) + self.We(y_cat),
                self.beta[i]
            )

            if x_gt is not None:
                x_hat_c = torch.complex(x_hat[:, :self.m], x_hat[:, self.m:])
                if NMSE_flag:
                    mse_vs_itr.append(torch.sum(torch.abs(x_hat_c.detach() - x_gt.detach()) ** 2).item()/torch.sum(torch.abs(x_gt.detach()) ** 2).item())

                else:  
                    mse_vs_itr.append(torch.sum(torch.abs(x_hat_c.detach() - x_gt.detach()) ** 2).item())

        x_hat_c = torch.complex(x_hat[:, :self.m], x_hat[:, self.m:])

        return x_hat_c, mse_vs_itr


def lista_toeplitz_apply(train_loader, test_loader, M1, M2, T, Phi, test_loader_off_grid=None):
    n = Phi.shape[0]
    m = Phi.shape[1]
    lista_toeplitz = LISTA_Toeplitz_Model(n, M1, M2, T=T, Phi=Phi)

    start = time.perf_counter()
    train(lista_toeplitz, train_loader, test_loader)
    end = time.perf_counter()
    print(f"Training took {end - start:.4f} seconds (Toeplitz)")
    
    # Extract all samples and calculate MSE for each iteration
    x_gt, y = test_loader.dataset.x, test_loader.dataset.y
    x_hat, mse_vs_iter = lista_toeplitz(y, x_gt=x_gt, NMSE_flag = True)

    if test_loader_off_grid is not None:
        x_hat_off_grid, mse_vs_iter_off_grid = lista_toeplitz(test_loader_off_grid.dataset.y, x_gt=test_loader_off_grid.dataset.x, NMSE_flag = True)
        mse_vs_iter_off_grid = np.array(mse_vs_iter_off_grid)
    
    mse_vs_iter = np.array(mse_vs_iter)

    if test_loader_off_grid is None:
        return x_hat.detach(), np.insert(mse_vs_iter, 0, 1), lista_toeplitz
    else:
        return x_hat.detach(), np.insert(mse_vs_iter, 0, 1), lista_toeplitz, x_hat_off_grid.detach(), np.insert(mse_vs_iter_off_grid, 0, 1)
   



    
