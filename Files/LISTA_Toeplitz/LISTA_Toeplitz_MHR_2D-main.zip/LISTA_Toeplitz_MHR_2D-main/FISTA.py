import numpy as np
import torch
import torch.nn.functional as F
from scipy.linalg import eigvalsh

def _complex_soft_threshold(x, beta, lambd):
    # x: [m] complex
    x_real, x_imag = x.real, x.imag
    mag = torch.sqrt(x_real**2 + x_imag**2 + 1e-12)
    scale = torch.clamp(1 - beta/(mag + 1e-12), min=0.0)
    x_real = x_real * scale
    x_imag = x_imag * scale
    return x_real + 1j * x_imag


def fista(y, H, b_x, rho=0.5, L=1, max_itr=300):
    loss_vs_iter = np.zeros(max_itr)

    x_hat = torch.zeros(H.shape[1], dtype=H.dtype)
    y_k = x_hat.clone()
    t_k = 1.0

    if H.dtype == torch.float64:
        proj = torch.nn.Softshrink(lambd=rho / L)

        for idx in range(max_itr):
            # Gradient + thresholding step
            x_new = proj(y_k - 1/L * (H.T @ (H @ y_k - y)))

            # Update t and y (Nesterov acceleration)
            t_new = (1 + np.sqrt(1 + 4 * t_k**2)) / 2
            y_k = x_new + ((t_k - 1) / t_new) * (x_new - x_hat)

            # Save for next iteration
            x_hat = x_new
            t_k = t_new

            # Loss
            loss_vs_iter[idx] = F.mse_loss(x_hat, b_x, reduction="sum").item()

    elif H.dtype == torch.complex128:
        for idx in range(max_itr):
            x_new = _complex_soft_threshold(
                y_k - 1/L * (H.H @ (H @ y_k - y)),
                beta=rho/L, lambd=rho
            )

            t_new = (1 + np.sqrt(1 + 4 * t_k**2)) / 2
            y_k = x_new + ((t_k - 1) / t_new) * (x_new - x_hat)

            x_hat = x_new
            t_k = t_new

            loss_vs_iter[idx] = torch.sum(torch.abs(x_hat - b_x) ** 2).item()

    return x_hat, loss_vs_iter


def fista_apply(test_loader, T, H, rho=0.1):
    H = H.cpu()
    m = H.shape[1]

    if H.dtype == torch.float64:
        L = float(eigvalsh(H.t() @ H, eigvals=(m - 1, m - 1)))
    elif H.dtype == torch.complex128:
        L = float(eigvalsh(H.H @ H, eigvals=(m - 1, m - 1)))

    losses = np.zeros((len(test_loader.dataset), T))
    norm_term = np.zeros(len(test_loader.dataset))
    x_hat = torch.zeros((len(test_loader.dataset), m), dtype=H.dtype)

    for idx, (y, _, b_x) in enumerate(test_loader.dataset):
        x_hat[idx, :], losses[idx, :] = fista(y=y, H=H, b_x=b_x, rho=rho, L=L, max_itr=T)
        norm_term[idx] = torch.sum(torch.abs(b_x) ** 2).item()

    losses_sum = np.sum(losses, axis=0)
    norm_term_sum = np.sum(norm_term)

    NMSE = losses_sum / norm_term_sum
    NMSE = np.insert(NMSE, 0, 1)

    return x_hat, NMSE







    
