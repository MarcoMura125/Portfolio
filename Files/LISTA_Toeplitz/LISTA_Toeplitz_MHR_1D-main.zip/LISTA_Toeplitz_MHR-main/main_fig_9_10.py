import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set, fourier_dict, db_to_lin, lin_to_db, compute_hit_rate

import json
import matplotlib.pyplot as plt

SEED = 0
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 3000        # number of training samples
N_test = 1000   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

# Fourier Matrix
Psi = fourier_dict(m)

T_LISTA = 10            # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 4 * T_LISTA   # number of iterations for ISTA and FISTA


noise_levels_db = range(-70, 21, 5)

results = {}

def run_experiment(method, noise_db):

    # Generate test dataset
    test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(noise_db)))

    # Dictonary estimation
    Y = test_loader.dataset.y  # N x n
    X = test_loader.dataset.x  # N x m

    match method:

        case 'LISTA':
            x_hat , nmse_vs_iter = lista(Y, x_gt=X, NMSE_flag=True)

        case 'LISTA_Toeplitz':
            x_hat , nmse_vs_iter = lista_toeplitz(Y, x_gt=X, NMSE_flag=True)

        case 'ISTA':
            x_hat , nmse_vs_iter = ista_apply(test_loader, T_ISTA, Phi, rho=0.1)

        case 'FISTA':
            x_hat , nmse_vs_iter = fista_apply(test_loader, T_ISTA, Phi, rho=0.1)

    return compute_hit_rate(X, x_hat, K=k), nmse_vs_iter[-1]  # return hit rate and NMSE of the last layer


### Train LISTA and LISTA-Toeplitz ###
random_indices = np.random.choice(m, n, replace=False)
omega = np.sort(random_indices)
R = torch.zeros((n,m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)
train_loader = create_data_set(Phi, n=n, m=m, k=k, N=N, noise_dev=np.sqrt(db_to_lin(-40)))
test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-40)))
Y = train_loader.dataset.y.t()  # Y toeplitz dataset paper notation n x N
X = train_loader.dataset.x.t()  # X toeplitz dataset paper notation m x N
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H
_ , _ , lista = lista_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)
_ , _ , lista_toeplitz = lista_toeplitz_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)


for method in ['LISTA', 'LISTA_Toeplitz', 'ISTA', 'FISTA']:
    results[method] = {
        "nmse_db": {},
        "hit_rate": {}
    }

    for noise_db in noise_levels_db:

        hit_rate, nmse = run_experiment(method=method, noise_db=noise_db)

        nmse_db = lin_to_db(nmse) # [dB]

        results[method]["nmse_db"][noise_db] = nmse_db
        results[method]["hit_rate"][noise_db] = hit_rate

        print(f"Method: {method}, Noise (dB): {noise_db}, Avg NMSE (dB): {nmse_db:.4f}, Hit Rate: {hit_rate:.4f}")


# Save results in a JSON file for later analysis
with open('trials/experiment_results_fig_9_10.json', 'w') as f:
    json.dump(results, f)


# Load the JSON data
with open("trials/experiment_results_fig_9_10.json", "r") as f:
    data = json.load(f)

### Plot NMSE vs Noise Power (Fig. 9) ###
# Prepare the plot
plt.figure(figsize=(8, 6))
# Plot each method
for method, results in data.items():
    noise_powers = [float(k) for k in results['nmse_db'].keys()]
    nmse_values = [v for v in results['nmse_db'].values()]
    match method:
        case 'ISTA':
            color = 'b'
        case 'FISTA':
            color = 'r'
        case 'LISTA':
            color = 'gold'
        case 'LISTA_Toeplitz':
            color = 'purple'
    plt.plot(noise_powers, nmse_values, marker="o", label=method, color=color)
plt.xlabel("Noise Power (dB)")
plt.ylabel("NMSE (dB)")
plt.title("NMSE vs Noise Power (Fig. 9)")
plt.legend()
plt.grid(True)
plt.tight_layout()
# plt.show()


### Plot Hit-Rate vs Noise Power (Fig. 10) ###
# Prepare the plot
plt.figure(figsize=(8, 6))
# Plot each method
for method, results in data.items():
    noise_powers = [float(k) for k in results['hit_rate'].keys()]
    nmse_values = [v for v in results['hit_rate'].values()]
    match method:
        case 'ISTA':
            color = 'b'
        case 'FISTA':
            color = 'r'
        case 'LISTA':
            color = 'gold'
        case 'LISTA_Toeplitz':
            color = 'purple'
    plt.plot(noise_powers, nmse_values, marker="o", label=method, color=color)
plt.xlabel("Noise Power (dB)")
plt.ylabel("Hit Rate (dB)")
plt.title("Hit Rate vs Noise Power (Fig. 10)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()











