# ## ISTA
# We begin by recalling the formulation of ISTA. The original algorihtm aims at solving the LASSO problem
# \begin{equation} 
# 	    \hat{\boldsymbol{s}} = \mathop{\arg\min}\limits_{\boldsymbol{s}} \frac{1}{2}\|\boldsymbol{x}-\boldsymbol{H}\boldsymbol{s}\|^2 +\rho\|\boldsymbol{s}\|_1,
# \end{equation}
# via the iterative update equations
# \begin{equation}
#          \boldsymbol{s}^{(k+1)} \leftarrow  \mathcal{T}_{\beta=\mu\rho}\left( \boldsymbol{s}^{(k)} - \mu \boldsymbol{H}^T(\boldsymbol{H}\boldsymbol{s}^{(k)}-\boldsymbol{x}) \right),    
# \end{equation}
# with $\mathcal{T}$ being the soft-thresholding operation.
# 
# Since one can probe convergence of ISTA when the step-size $\mu$ satisfies $\mu \leq \frac{1}{\max {\rm eig}(\boldsymbol{H}^T\boldsymbol{H})}$, we will use this value as our default setting of $\mu = 1/L$ with $L=\max {\rm eig}(\boldsymbol{H}^T\boldsymbol{H})$.


import numpy as np
import torch
import torch.nn.functional as F
from scipy.linalg import eigvalsh 

def _complex_soft_threshold( x, beta, lambd):
    # x: [m] complex
    m = x.shape[0]
    x_real, x_imag = x.real, x.imag
    mag = torch.sqrt(x_real**2 + x_imag**2 + 1e-12)
    scale = torch.clamp(1 -  beta / (mag + 1e-12), min=0.0)
    x_real = x_real * scale
    x_imag = x_imag * scale
    return x_real + 1j * x_imag


def ista(y, H, b_x, rho=0.5, L=1, max_itr=300):
    
    loss_vs_iter = np.zeros(max_itr)
    x_hat = torch.zeros(H.shape[1], dtype=H.dtype)
    
    # ISTA iterations
    if H.dtype == torch.float64:
        proj = torch.nn.Softshrink(lambd=rho / L)

        for idx in range(max_itr):
            x_tild = x_hat - 1 / L * (H.T @ (H @ x_hat - y))
            x_hat = proj(x_tild)
            # Aggregate each iteration's MSE loss
            loss_vs_iter[idx] = F.mse_loss(x_hat, b_x, reduction="sum").data.item()
    
    elif H.dtype == torch.complex128:

        for idx in range(max_itr):
            x_tild = x_hat - 1 / L * (H.H @ (H @ x_hat - y))
            x_hat = _complex_soft_threshold( x_tild, beta=rho/L , lambd=rho)
            # Aggregate each iteration's MSE loss
            loss_vs_iter[idx] = torch.sum(torch.abs(x_hat - b_x) ** 2).item()

    return x_hat, loss_vs_iter

def ista_apply(test_loader, T, H, rho=0.1):
    H = H.cpu()
    m = H.shape[1]

    if H.dtype == torch.float64:
        L = float(eigvalsh(H.t() @ H, eigvals=(m - 1, m - 1)))  # returns the max eigenvalue of: H.t() @ H
    elif H.dtype == torch.complex128:
        L = float(eigvalsh(H.H @ H, eigvals=(m - 1, m - 1)))  # returns the max eigenvalue of: H.H @ H
    
    # Aggregate T iterations' MSE loss
    losses = np.zeros((len(test_loader.dataset), T))
    norm_term = np.zeros(len(test_loader.dataset))
    x_hat = torch.zeros((len(test_loader.dataset), m), dtype=H.dtype)
    for idx, (y, _, b_x) in enumerate(test_loader.dataset):
        x_hat[idx, :], losses[idx, :] = ista(y=y, H=H, b_x=b_x, rho=rho, L=L, max_itr=T)
        norm_term [idx] = torch.sum(torch.abs(b_x) ** 2).item()
    # print(idx)

    losses_sum = np.sum(losses, axis=0)
    norm_term_sum = np.sum(norm_term)

    # print(b_x.shape)

    # print(losses_sum.shape)
    NMSE = losses_sum / norm_term_sum
    NMSE = np.insert(NMSE, 0, 1)  # Insert the 0-th iteration (all zero vector)
    #torch.sum(torch.abs(b_x) ** 2).item()

    # return losses.mean(axis=0)

    return x_hat, NMSE
