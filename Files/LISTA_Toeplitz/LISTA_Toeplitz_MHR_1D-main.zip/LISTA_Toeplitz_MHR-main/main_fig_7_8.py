import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set_2, fourier_dict, db_to_lin

SEED = 312
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 3000        # number of training samples
N_test = 1000   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

T_LISTA = 5             # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 20 * T_LISTA   # number of iterations for ISTA and FISTA

### Construct Fourier-based measurement matrix Phi ###
Psi = fourier_dict(m)
random_indices = np.random.choice(m, n, replace=False) 
omega = np.sort(random_indices)
R = torch.zeros((n, m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)

### Generate synthetic datasets (training & test) ###
train_loader , _ = create_data_set_2(Phi, n=n, m=m, k=k, omega=omega, shift=0.25, N=N, noise_dev=np.sqrt(db_to_lin(-30)))
test_loader , test_loader_off_grid = create_data_set_2(Phi, n=n, m=m, k=k, N=N_test, omega=omega, shift=0.25, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-30)))


### Dictonary estimation ###
Y = train_loader.dataset.y.t()  # Y toeplitz dataset paper notation n x N
X = train_loader.dataset.x.t()  # X toeplitz dataset paper notation m x N
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H


### Comparing the different methods ###
x_hat_ista , ista_mse_vs_iter = ista_apply(test_loader, T_ISTA, Phi, rho=0.02)
x_hat_fista , fista_mse_vs_iter = fista_apply(test_loader, T_ISTA, Phi, rho=0.02)
x_hat_ista_off_grid , ista_mse_vs_iter_off_grid = ista_apply(test_loader_off_grid, T_ISTA, Phi, rho=0.02)
x_hat_fista_off_grid , fista_mse_vs_iter_off_grid = fista_apply(test_loader_off_grid, T_ISTA, Phi, rho=0.02)

x_hat_lista, lista_mse_vs_iter, _ , x_hat_lista_off_grid, lista_off_grid_mse_vs_iter = lista_apply(train_loader, test_loader, T_LISTA, Phi_est,
                                                                                                    test_loader_off_grid=test_loader_off_grid, init_Wg=False)

x_hat_toeplitz, lista_toeplitz_mse_vs_iter, _ , x_hat_toeplitz_off_grid, lista_toeplitz_off_grid_mse_vs_iter = lista_toeplitz_apply(train_loader, test_loader, T_LISTA, Phi_est,
                                                                                                                                    test_loader_off_grid=test_loader_off_grid, init_Wg=False)

x_gt = test_loader.dataset.x

x_gt_off_grid = test_loader_off_grid.dataset.x


### Plot the results (NMSE vs iterations/layers) ###
fig = plt.figure()
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter, label='ISTA', color='b', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter_off_grid, label='ISTA (off grid)', color='b', linewidth=0.5, marker='*', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter, label='FISTA', color='r', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter_off_grid, label='FISTA (off grid)', color='r', linewidth=0.5, marker='*', markerfacecolor='none')
plt.plot(range(T_LISTA + 1), lista_mse_vs_iter, label='LISTA', color='gold', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_LISTA + 1), lista_off_grid_mse_vs_iter, label='LISTA (off grid)', color='gold', linewidth=0.5, marker='*', markerfacecolor='none')
plt.plot(range(T_LISTA + 1), lista_toeplitz_mse_vs_iter, label='LISTA-Toeplitz', color='purple', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_LISTA + 1), lista_toeplitz_off_grid_mse_vs_iter, label='LISTA-Toeplitz (off grid)', color='purple', linewidth=0.5, marker='*', markerfacecolor='none')
plt.title('NMSE vs Iterations')
plt.xlabel('Number of iteration/layer', fontsize=10)
plt.ylabel('NMSE', fontsize=10)
plt.yscale("log")
plt.legend()
plt.grid(True)
plt.show()


def custom_stem(freqs, values, color, marker, label=None, thresh=0.05):
    """Stem plot con astine e marker solo sopra soglia."""
    values = values.detach().cpu().numpy() if torch.is_tensor(values) else values
    freqs = np.asarray(freqs)

    mask = values > thresh
    freqs_masked = freqs[mask]
    values_masked = values[mask]

    if len(freqs_masked) > 0:
        stemlines = plt.stem(freqs_masked, values_masked, basefmt=" ", 
                             linefmt=color, markerfmt=" ")[1]
        plt.setp(stemlines, linewidth=1.0, color=color)

        plt.plot(freqs_masked, values_masked, linestyle="None",
                 marker=marker, color=color, markerfacecolor="none", label=label)



#### Plot recovered spectrum (FIGURE 7) ####
freqs = np.linspace(0, 1, m, endpoint=False)

sample_idx = 7  # Index of the sample to plot

#### FIGURE 7 ####
plt.figure(figsize=(10, 4))
custom_stem(freqs, torch.abs(x_gt[sample_idx,:]), color="k", marker="o", label="Ground truth")
custom_stem(freqs, torch.abs(x_hat_ista[sample_idx,:]), color="b", marker="*", label="ISTA")
custom_stem(freqs, torch.abs(x_hat_fista[sample_idx,:]), color="r", marker="^", label="FISTA")
custom_stem(freqs, torch.abs(x_hat_lista[sample_idx,:]), color="gold", marker="s", label="LISTA")
custom_stem(freqs, torch.abs(x_hat_toeplitz[sample_idx,:]), color="purple", marker="D", label="LISTA-Toeplitz")

plt.xlabel("Normalized frequency")
plt.ylabel("Magnitude")
plt.title("Recovered harmonic components (on-the-grid)")
plt.legend(loc="upper left")
plt.grid(True, linestyle="--", alpha=0.6)
plt.xlim(0, 1)
plt.tight_layout()


#### FIGURE 8 ####
plt.figure(figsize=(10, 4))
custom_stem(freqs, torch.abs(x_gt[sample_idx,:]), color="k", marker="o", label="Ground truth")
custom_stem(freqs, torch.abs(x_hat_ista_off_grid[sample_idx,:]), color="b", marker="*", label="ISTA")
custom_stem(freqs, torch.abs(x_hat_fista_off_grid[sample_idx,:]), color="r", marker="^", label="FISTA")
custom_stem(freqs, torch.abs(x_hat_lista_off_grid[sample_idx,:]), color="gold", marker="s", label="LISTA")
custom_stem(freqs, torch.abs(x_hat_toeplitz_off_grid[sample_idx,:]), color="purple", marker="D", label="LISTA-Toeplitz")

plt.xlabel("Normalized frequency")
plt.ylabel("Magnitude")
plt.title("Recovered harmonic components (off-the-grid)")
plt.legend(loc="upper left")
plt.grid(True, linestyle="--", alpha=0.6)
plt.xlim(0, 1)
plt.tight_layout()
plt.show()
