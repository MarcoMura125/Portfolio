import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set, fourier_dict, db_to_lin

SEED = 312
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 3000        # number of training samples
N_test = 1000   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

T_LISTA = 10            # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 20 * T_LISTA   # number of iterations for ISTA and FISTA

### Construct Fourier-based measurement matrix Phi ###
Psi = fourier_dict(m)
random_indices = np.random.choice(m, n, replace=False)
omega = np.sort(random_indices)
R = torch.zeros((n,m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)

### Generate synthetic datasets (training & test) ###
train_loader = create_data_set(Phi, n=n, m=m, k=k, N=N, noise_dev=np.sqrt(db_to_lin(-40)))
test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-40)))

### Dictonary estimation ###
Y = train_loader.dataset.y.t()  # Y dataset paper notation n x N
X = train_loader.dataset.x.t()  # X dataset paper notation m x N
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H 

### Apply the different methods ###
_ , lista_mse_vs_iter, _ = lista_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)

_ , lista_toeplitz_mse_vs_iter , _ = lista_toeplitz_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)

_ , ista_mse_vs_iter_002 = ista_apply(test_loader, T_ISTA, Phi, rho=0.02)
_ , ista_mse_vs_iter_01 = ista_apply(test_loader, T_ISTA, Phi, rho=0.1)
_ , ista_mse_vs_iter_05 = ista_apply(test_loader, T_ISTA, Phi, rho=0.5)

_ , fista_mse_vs_iter_002 = fista_apply(test_loader, T_ISTA, Phi, rho=0.02)
_ , fista_mse_vs_iter_01 = fista_apply(test_loader, T_ISTA, Phi, rho=0.1)
_ , fista_mse_vs_iter_05 = fista_apply(test_loader, T_ISTA, Phi, rho=0.5)



#### Plot NMSE vs number of iterations/layers (FIGURE 4) ####
fig = plt.figure()


### Plot the results (NMSE vs iterations/layers) ###
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter_002, label='ISTA λ=0.02', color='b', linewidth=0.5)
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter_01, label='ISTA λ=0.1', color='b', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter_05, label='ISTA λ=0.5', color='b', linewidth=0.5, marker='*', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter_002, label='FISTA λ=0.02', color='r', linewidth=0.5)
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter_01, label='FISTA λ=0.1', color='r', linewidth=0.5, marker='o', markerfacecolor='none')
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter_05, label='FISTA λ=0.5', color='r', linewidth=0.5, marker='*', markerfacecolor='none')
plt.plot(range(T_LISTA + 1), lista_mse_vs_iter, label='LISTA', color='gold', linewidth=2)
plt.plot(range(T_LISTA + 1), lista_toeplitz_mse_vs_iter, label='LISTA_Toeplitz', color='purple', linewidth=2)
plt.title('NMSE vs Number of iterations/layers', fontsize=12)
plt.xlabel('Number of iteration/layer', fontsize=10)
plt.ylabel('NMSE', fontsize=10)
plt.yscale("log")
plt.legend()
plt.grid(True)
plt.show()
