import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set, fourier_dict, db_to_lin, lin_to_db

SEED = 312
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 2000        # number of training samples
N_test = 100   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

T_LISTA = 10            # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 20 * T_LISTA   # number of iterations for ISTA and FISTA

### Construct Fourier-based measurement matrix Phi ###
Psi = fourier_dict(m)
random_indices = np.random.choice(m, n, replace=False)
omega = np.sort(random_indices)
R = torch.zeros((n,m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)

### Generate synthetic datasets (training & test) ###
train_loader = create_data_set(Phi, n=n, m=m, k=k, N=N, noise_dev=np.sqrt(db_to_lin(-30)))
test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-30)))


### Dictonary estimation ###
Y = train_loader.dataset.y.t()  # Y dataset paper notation [n x N]
X = train_loader.dataset.x.t()  # X dataset paper notation [m x N]
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H


### Apply the different methods ###
_ , lista_mse_vs_iter, lista_loss_train,  lista_loss_test = lista_apply(train_loader, test_loader, T_LISTA, Phi_est, 
                                                                        ret_loss=True, num_epochs=100, lambd=0.05)

_ , lista_toeplitz_mse_vs_iter, lista_toeplitz_loss_train,  lista_toeplitz_loss_test  = lista_toeplitz_apply(train_loader, test_loader, T_LISTA, Phi_est,
                                                                                                              ret_loss=True, num_epochs=100, lambd=0.05)

### Plot the results (train and test loss vs training epochs) ###
fig = plt.figure() 
plt.plot(lin_to_db(lista_loss_train), label = 'LISTA loss on training set', color='gold', linewidth=0.5, marker='o', markerfacecolor='none' ) 
plt.plot(lin_to_db(lista_loss_test), label = 'LISTA loss on validation set', color='gold', linewidth=0.5, marker='*' )
plt.plot(lin_to_db(lista_toeplitz_loss_train), label = 'LISTA-Toeplitz loss on training set', color='purple', linewidth=0.5, marker='o', markerfacecolor='none'  ) 
plt.plot(lin_to_db(lista_toeplitz_loss_test), label = 'LISTA-Toeplitz loss on validation set', color='purple', linewidth=0.5, marker='*' )
plt.xlabel('Epoch', fontsize=10)
plt.ylabel('Loss/dB', fontsize=10)
plt.legend( )
plt.grid(True)
plt.show()
