import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set, fourier_dict, db_to_lin, lin_to_db

import json
import matplotlib.pyplot as plt

SEED = 0
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 3000        # number of training samples
N_test = 1000   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

Psi = fourier_dict(m)  # Fourier Matrix

num_layers_list = range(2, 11, 2)    # 2 to 10 layers
noise_levels_db = range(-40, 12, 3)  # from -40 dB to 11 dB (step can be tuned)

results = {}

def run_experiment(method, num_layers, noise_db):

    ### Construct Fourier-based measurement matrix Phi ###
    random_indices = np.random.choice(m, n, replace=False)
    omega = np.sort(random_indices)
    R = torch.zeros((n,m), dtype=torch.complex128)
    for i, idx in enumerate(omega):
        R[i, idx] = 1.0
    Phi = R @ Psi
    Phi /= torch.norm(Phi, dim=0)

    ### Generate synthetic datasets (training & test) ###
    train_loader = create_data_set(Phi, n=n, m=m, k=k, N=N, noise_dev=np.sqrt(db_to_lin(noise_db)))
    test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test,
                                            batch_size=N_test, noise_dev=np.sqrt(db_to_lin(noise_db)))

    ### Dictonary estimation ###
    Y = train_loader.dataset.y.t()  # Y dataset paper notation [n x N]
    X = train_loader.dataset.x.t()  # X dataset paper notation [m x N]
    Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H 

    match method:

        case 'LISTA':
            _ , nmse_vs_iter , _ = lista_apply(train_loader, test_loader, num_layers, Phi_est)


        case 'LISTA_Toeplitz':
            _ , nmse_vs_iter , _ = lista_toeplitz_apply(train_loader, test_loader, num_layers, Phi_est)


    return nmse_vs_iter[-1]  # return NMSE of the last layer

for method in ['LISTA', 'LISTA_Toeplitz']:
    results[method] = {}
    for num_layers in num_layers_list:
        results[method][num_layers] = {}
        for noise_db in noise_levels_db:
            nmse = lin_to_db( run_experiment(method=method, num_layers=num_layers, noise_db=noise_db) )             
            results[method][num_layers][noise_db] = nmse
            print(f"Method: {method}, Layers: {num_layers}, Noise (dB): {noise_db}, NMSE (dB): {nmse:.4f}")

### Save results in a JSON file for later analysis ###
with open('trials/experiment_results_fig3.json', 'w') as f:
    json.dump(results, f)


### PLOT RESULTS ###

### Load JSON data ###
with open("trials/experiment_results_fig3.json", "r") as f:
    results = json.load(f)

### Extract layers and noise levels ###
layers = sorted([int(k) for k in results["LISTA_Complex"].keys()])
noise_levels = sorted([int(k) for k in results["LISTA_Complex"][str(layers[0])].keys()])

### Prepare NMSE matrices ###
nmse_lista = np.array([[results["LISTA_Complex"][str(l)][str(n)]
                        for l in layers] for n in noise_levels])
nmse_toeplitz = np.array([[results["LISTA_Toeplitz"][str(l)][str(n)]
                           for l in layers] for n in noise_levels])

### Plotting ###
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

titles = ["LISTA", "LISTA-Toeplitz"]
data = [nmse_lista, nmse_toeplitz]

for ax, nmse, title in zip(axes, data, titles):
    im = ax.imshow(
        nmse, aspect="auto", origin="lower",
        extent=[min(layers), max(layers), min(noise_levels), max(noise_levels)],
        cmap="viridis_r"
    )
    ax.set_title(title)
    ax.set_xlabel("Number of layers T")
    ax.set_ylabel("Noise power (dB)")
    ax.set_xticks(layers)
    ax.set_yticks(noise_levels)

### Add a single colorbar on the far right ###
cbar_ax = fig.add_axes([0.92, 0.15, 0.02, 0.7])  # [left, bottom, width, height]
fig.colorbar(im, cax=cbar_ax, label="Recovered NMSE (dB)")
plt.tight_layout(rect=[0, 0, 0.9, 1])  # leave space on the right
plt.show()


