import torch 
import torch.nn.functional as F
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt

from ISTA import *
from FISTA import *
from LISTA import *
from LISTA_Toeplitz import *
from utils import create_data_set, fourier_dict, db_to_lin

SEED = 312
torch.manual_seed(SEED)
np.random.seed(SEED)

torch.set_default_dtype(torch.float64)

N = 3000        # number of training samples
N_test = 1000   # number of test samples

n = 64      # dimension of measurement vector y
m = 128     # dimension of sparse signal x
k = 4       # sparsity level (k-sparse signal)

T_LISTA = 10            # number of layers for LISTA and LISTA Toeplitz
T_ISTA = 20 * T_LISTA   # number of iterations for ISTA and FISTA

### Construct Fourier-based measurement matrix Phi ###
Psi = fourier_dict(m)
random_indices = np.random.choice(m, n, replace=False)
omega = np.sort(random_indices)
R = torch.zeros((n,m), dtype=torch.complex128)
for i, idx in enumerate(omega):
    R[i, idx] = 1.0
Phi = R @ Psi
Phi /= torch.norm(Phi, dim=0)

### Generate synthetic datasets (training & test) ###
train_loader = create_data_set(Phi, n=n, m=m, k=k, N=N, noise_dev=np.sqrt(db_to_lin(-40)))
test_loader = create_data_set(Phi, n=n, m=m, k=k, N=N_test, batch_size=N_test, noise_dev=np.sqrt(db_to_lin(-40)))

### Let's see what the samples look like ###
# y_exm, _, x_exm = test_loader.dataset.__getitem__(5)
# plt.figure(figsize=(8, 8)) 
# plt.subplot(2, 1, 1) 
# plt.plot(y_exm, label = 'observation' ) 
# plt.xlabel('Index', fontsize=10)
# plt.ylabel('Value', fontsize=10)
# plt.legend( )
# plt.subplot (2, 1, 2) 
# plt.plot(x_exm, label = 'sparse signal', color='k')  
# plt.xlabel('Index', fontsize=10)
# plt.ylabel('Value', fontsize=10)
# plt.legend( )
# plt.show()

### Dictonary estimation ###
Y = train_loader.dataset.y.t()  # Y dataset paper notation [n x N]
X = train_loader.dataset.x.t()  # X dataset paper notation [m x N]
Phi_est = Y @ torch.pinverse(X.H @ X) @ X.H 


### Comparing the different methods ###
_ , lista_mse_vs_iter, _ = lista_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)  # Train and apply LISTA with T layers
_ , lista_toeplitz_mse_vs_iter , _ = lista_toeplitz_apply(train_loader, test_loader, T_LISTA, Phi_est, init_Wg=True)  # Train and apply LISTA Toeplitz with T layers
_ , ista_mse_vs_iter = ista_apply(test_loader, T_ISTA, Phi, rho=0.02)       # Apply ISTA for T iterations
_ , fista_mse_vs_iter = fista_apply(test_loader, T_ISTA, Phi, rho=0.02)     # Apply FISTA for T iterations



### Plot the results (NMSE vs iterations/layers) ###
fig = plt.figure()
plt.plot(range(T_ISTA + 1), ista_mse_vs_iter, label='ISTA', color='b', linewidth=0.5)
plt.plot(range(T_ISTA + 1), fista_mse_vs_iter, label='FISTA', color='r', linewidth=0.5)
plt.plot(range(T_LISTA + 1), lista_mse_vs_iter, label='LISTA', color='gold', linewidth=2)
plt.plot(range(T_LISTA + 1), lista_toeplitz_mse_vs_iter, label='LISTA_Toeplitz', color='purple', linewidth=2)
plt.title('NMSE vs Number of iterations/layers', fontsize=12)
plt.xlabel('Number of iteration/layer', fontsize=10)
plt.ylabel('NMSE', fontsize=10)
plt.yscale("log")
plt.legend()
plt.grid(True)
plt.show()

