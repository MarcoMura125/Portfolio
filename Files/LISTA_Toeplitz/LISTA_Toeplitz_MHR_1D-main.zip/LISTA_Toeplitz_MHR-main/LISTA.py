
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from utils import train
from scipy.linalg import eigvalsh

import time 

# Lista Model
class LISTA_Model(nn.Module):
    def __init__(self, n, m, T=6, lambd=0.02, Phi=None, init_Wg=False):
        super().__init__()
        self.n, self.m = n, m
        self.T = T
        self.lambd = lambd

        # Linear layers
        self.We = nn.Linear(2*m, 2*n, bias=False)
        self.Wg = nn.Linear(2*m, 2*m, bias=False)

        L = float(eigvalsh(Phi.H @ Phi, eigvals=(m - 1, m - 1)))  # returns the max eigenvalue of: Phi.H @ Phi

        self.beta = nn.Parameter( (lambd/L) * torch.ones(T + 1, 1, 1), requires_grad=True)

        if Phi is not None:
            # Construct the real block matrix for Phi
            Phi_r = Phi.real
            Phi_i = Phi.imag
            Phi_block = torch.cat([
                torch.cat([Phi_r, -Phi_i], dim=1),
                torch.cat([Phi_i,  Phi_r], dim=1)
            ], dim=0)

            # Initialize We
            self.We.weight.data = (1/L) * Phi_block.t()

            # Initialize Wg
            if init_Wg:
                # Construct the real block matrix for the Gram matrix
                Gram = Phi.H @ Phi
                Gram_r = Gram.real
                Gram_i = Gram.imag
                Gram_block = torch.cat([
                    torch.cat([Gram_r, -Gram_i], dim=1),
                    torch.cat([Gram_i,  Gram_r], dim=1)
                ], dim=0)
                self.Wg.weight.data = torch.eye(2*m) - (1/L) * Gram_block  # init based on the Phi estimate
            else:
                self.Wg.weight.data = torch.zeros(2*m, 2*m)   # init to zero
            


    def _complex_soft_threshold(self, x, beta):
        # x: [batch, 2*m] (Re, Im)
        x_real, x_imag = x[:, :self.m], x[:, self.m:]
        mag = torch.sqrt(x_real**2 + x_imag**2 + 1e-12)
        scale = torch.clamp(1 -  beta / (mag + 1e-12), min=0.0)
        x_real = x_real * scale
        x_imag = x_imag * scale
        return torch.cat([x_real, x_imag], dim=1)
    

    def forward(self, y, x_gt=None, NMSE_flag=False):
        # y: [batch, n] complex -> [batch, 2*n] real
        # x_gt: [batch, m] complex
        y_cat = torch.cat([y.real, y.imag], dim=1)
        mse_vs_itr = []

        # Initialize x_hat
        x_hat = self._complex_soft_threshold(self.We(y_cat), self.beta[0])

        # Run the network
        for i in range(1, self.T + 1):

            #start = time.perf_counter()

            x_hat = self._complex_soft_threshold(
                self.Wg(x_hat) + self.We(y_cat),
                self.beta[i]
            )

            #end = time.perf_counter()
            #print(f"Iteration {i} took {end - start:.4f} seconds (Complex)")    

            # Compute MSE or NMSE per layer
            if x_gt is not None:
                x_hat_c = torch.complex(x_hat[:, :self.m], x_hat[:, self.m:])
                if NMSE_flag:
                    mse_vs_itr.append(torch.sum(torch.abs(x_hat_c.detach() - x_gt.detach()) ** 2).item()/torch.sum(torch.abs(x_gt.detach()) ** 2).item())
                else:  
                    mse_vs_itr.append(torch.sum(torch.abs(x_hat_c.detach() - x_gt.detach()) ** 2).item())

        x_hat_c = torch.complex(x_hat[:, :self.m], x_hat[:, self.m:])

        return x_hat_c, mse_vs_itr



def lista_apply(train_loader, test_loader, T, Phi, test_loader_off_grid=None, ret_loss=False, num_epochs=50, init_Wg=False, lambd=0.02):
    n = Phi.shape[0]
    m = Phi.shape[1]
    lista = LISTA_Model(n=n, m=m, T=T, Phi=Phi, init_Wg=init_Wg, lambd=lambd)
    
    start = time.perf_counter()
    loss_train, loss_test = train(lista, train_loader, test_loader, num_epochs=num_epochs)
    end = time.perf_counter()
    print(f"Training took {end - start:.4f} seconds (LISTA)")
    
    # Extract all samples and calculate MSE for each iteration
    x_gt, y = test_loader.dataset.x, test_loader.dataset.y
    x_hat, mse_vs_iter = lista(y, x_gt=x_gt, NMSE_flag = True)

    if test_loader_off_grid is not None:
        x_hat_off_grid, mse_vs_iter_off_grid = lista(test_loader_off_grid.dataset.y, x_gt=test_loader_off_grid.dataset.x, NMSE_flag = True)
        mse_vs_iter_off_grid = np.array(mse_vs_iter_off_grid)

    # print(mse_vs_iter[-1])

    mse_vs_iter = np.array(mse_vs_iter)

    if ret_loss:
        return x_hat.detach(), np.insert(mse_vs_iter, 0, 1), loss_train, loss_test
   
    if test_loader_off_grid is None:
        return x_hat.detach(), np.insert(mse_vs_iter, 0, 1), lista
    else:
        return x_hat.detach(), np.insert(mse_vs_iter, 0, 1), lista, x_hat_off_grid.detach(), np.insert(mse_vs_iter_off_grid, 0, 1)
