%% ANIMATION OF THE RANDLES CIRCUIT
% Shows the effect of the redox species concentrations 
% on the Nyquist plot of the Randles equivalent circuit.
% The resulting video is saved as "Randles_C_Variation.mp4".

clc; clear; close all;

% -----------------------------
% Physical constants
% -----------------------------
R = 8.314;        % Gas constant [J/mol/K]
T = 298;          % Temperature [K]
F = 96485;        % Faraday constant [C/mol]
A = 1e-4;         % Electrode area [m^2]
n = 1;            % Number of electrons transferred

% -----------------------------
% Electrolyte parameters
% -----------------------------
DO = 1e-9;        % Diffusion coefficient of oxidized species [m^2/s]
DR = 1e-9;        % Diffusion coefficient of reduced species [m^2/s]

% -----------------------------
% Equivalent circuit parameters
% -----------------------------
Re  = 5;          % Electrolyte resistance [Ω]
Rct = 50;         % Charge transfer resistance [Ω]
Cdl = 20e-6;      % Double-layer capacitance [F]

% -----------------------------
% Frequency range
% -----------------------------
f = logspace(5, -2, 200);   % From 100 kHz to 0.01 Hz
w = 2 * pi * f;

% -----------------------------
% Video setup
% -----------------------------
videoName = 'Randles_C_Variation.mp4';
v = VideoWriter(videoName, 'MPEG-4');
v.FrameRate = 1;   % 1 frame per second (adjustable)
open(v);

disp('Starting Nyquist animation rendering...');

% -----------------------------
% Concentration variation
% -----------------------------
CO_values = linspace(0.5, 5, 10);   % From 0.5 to 5 mol/m³ (10 steps)
CR_values = linspace(0.5, 5, 10);
colors = parula(length(CO_values));

% -----------------------------
% Main figure setup
% -----------------------------
figure('Position', [100 100 700 600]);
hold on; grid on; axis equal;
axis([0 120 0 120]);
xlabel('Re(Z) [Ω]', 'FontSize', 12);
ylabel('-Im(Z) [Ω]', 'FontSize', 12);
title('Nyquist Plot - Effect of Concentration', 'FontSize', 14);

% -----------------------------
% Simulation and frame capture
% -----------------------------
for k = 1:length(CO_values)
    CO = CO_values(k);
    CR = CR_values(k);
    
    % Warburg impedance (semi-infinite)
    sigma = (R * T) / (sqrt(2) * A * (n * F)^2) * ...
             (1 / (CO * sqrt(DO)) + 1 / (CR * sqrt(DR)));
    Zw = sigma ./ sqrt(1j * w);
    
    % Total impedance
    Z_RplusW = Rct + Zw;
    Z_C = 1 ./ (1j * w * Cdl);
    Z_par = 1 ./ (1 ./ Z_C + 1 ./ Z_RplusW);
    Ztot = Re + Z_par;
    
    % Nyquist plot
    plot(real(Ztot), -imag(Ztot), 'LineWidth', 2, 'Color', colors(k,:));
    
    % Dynamic legend
    legendText = sprintf('C_O = %.2f mol/m^3,  C_R = %.2f mol/m^3', CO, CR);
    legend(legendText, 'Location', 'northwest');
    
    drawnow;
    
    % Write frame to video
    frame = getframe(gcf);
    writeVideo(v, frame);
    
    pause(0.2);  % Pause for smoother animation
end

% -----------------------------
% Finalization
% -----------------------------
close(v);
disp(['Animation complete. Video saved as ', videoName]);
