%% Randles Circuit: Re - [ Cdl || (Rct + Zw) ]
clc; clear; close all;

% -----------------------------
% Physical constants
% -----------------------------
R = 8.314;        % Gas constant [J/mol/K]
T = 298;          % Temperature [K]
F = 96485;        % Faraday constant [C/mol]
A = 1e-4;         % Electrode area [m^2]
n = 1;            % Number of electrons transferred

% -----------------------------
% Concentrations and diffusivities
% -----------------------------
CO = 1;           % Oxidized species concentration [mol/m^3]
CR = 1;           % Reduced species concentration [mol/m^3]
DO = 1e-9;        % Diffusion coefficient of oxidized species [m^2/s]
DR = 1e-9;        % Diffusion coefficient of reduced species [m^2/s]

% -----------------------------
% Equivalent circuit parameters
% -----------------------------
Re  = 5;          % Electrolyte resistance [Ω]
Rct = 50;         % Charge transfer resistance [Ω]
Cdl = 20e-6;      % Double-layer capacitance [F]

% -----------------------------
% Frequency range (log scale)
% -----------------------------
f = logspace(5, -2, 200);   % From 100 kHz to 0.01 Hz
w = 2 * pi * f;

% -----------------------------
% Warburg impedance (semi-infinite)
% -----------------------------
sigma = (R * T) / (sqrt(2) * A * (n * F)^2) * ...
         (1 / (CO * sqrt(DO)) + 1 / (CR * sqrt(DR)));

Zw = sigma ./ sqrt(1j * w);   % Zw = σ / √(jω)

% -----------------------------
% Total impedance computation
% -----------------------------
Z_RplusW = Rct + Zw;                     % Series branch: charge transfer + diffusion
Z_C = 1 ./ (1j * w * Cdl);               % Capacitive branch
Z_par = 1 ./ (1 ./ Z_C + 1 ./ Z_RplusW); % Parallel combination: Cdl || (Rct + Zw)
Ztot = Re + Z_par;                       % Total impedance (series with Re)

% -----------------------------
% Nyquist plot
% -----------------------------
figure;
plot(real(Ztot), -imag(Ztot), 'LineWidth', 1.8);
xlabel('Re(Z) [Ω]');
ylabel('-Im(Z) [Ω]');
title('Nyquist Plot - Randles Circuit');
grid on;
pbaspect([1 1 1]);
axis([0 120 0 120]);

% Annotate selected frequencies
f_mark = [0.5 1 10 100 1000];
offsetX = 3; offsetY = 0;

for k = 1:length(f_mark)
    [~, idx] = min(abs(f - f_mark(k)));
    text(real(Ztot(idx)) + offsetX, ...
         -imag(Ztot(idx)) + offsetY, ...
         sprintf(' %.2g Hz', f_mark(k)), ...
         'FontSize', 8, 'Color', 'b');
end

disp('Nyquist plot generated successfully.');

% -----------------------------
% Bode plots (magnitude and phase)
% -----------------------------
figure;

subplot(2,1,1);
loglog(f, abs(Ztot), 'LineWidth', 1.8);
xlabel('Frequency [Hz]');
ylabel('|Z| [Ω]');
title('Bode Plot - Magnitude');
grid on;

subplot(2,1,2);
semilogx(f, angle(Ztot) * 180 / pi, 'LineWidth', 1.8);
xlabel('Frequency [Hz]');
ylabel('Phase [°]');
title('Bode Plot - Phase');
grid on;

disp('Bode plots generated successfully.');
