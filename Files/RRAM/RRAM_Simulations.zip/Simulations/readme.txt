This folder contains all the MATLAB scripts and Simulink models used in this project. 

All files were written by the author, except for the function create_rram_array.m and 

those within the Parameters folder, which contains the characterization parameters of 

the four different technology devices considered.



Each .m file is intended to reproduce one of the figures presented in the project report.