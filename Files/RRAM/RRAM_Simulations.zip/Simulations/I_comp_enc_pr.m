clc; clear; close all;

%% ==================== General Parameters ====================
N = 5;                      % crossbar size (5x5)
N_tests = 20;                % number of Monte Carlo runs
Tech_number = 3;            % technology ID
Variability_seed = 42;      % base seed for variability
RTN_seed = 7;               % base seed for RTN

%% ==================== Simscape Parameters ====================
R0 = 1e4;                   % reference value for Simulink
Rp_values = 3:20:103;       % line parasitic resistances (Ohm)

%% ==================== Encoding Parameters ====================
n_bit = 4;                  % fixed bit depth
n_levels = 2^n_bit;         % quantization levels
Icomp_min = 1e-5;           % minimum compliance current
Icomp_max = 1e-3;           % maximum compliance current

%% ==================== Results Matrices ====================
% Dimensions: [Rp_index, MonteCarlo_run, Case]
% Case = 1 → ideal (no variability, no RTN)
% Case = 2 → non-ideal (variability + RTN)
NRMSE_all = zeros(length(Rp_values), N_tests, 2);

%% ==================== Main Simulation Loop ====================
for r_idx = 1:length(Rp_values)
    Rp = Rp_values(r_idx);
    fprintf('\n=== Simulating with line parasitic resistance Rp = %.0f Ω ===\n', Rp);

    for k = 1:N_tests
        rng(1000 + r_idx*100 + k);  % reproducibility

        %% Generate invertible random matrix
        A = rand(N) + 0.1;
        while abs(det(A)) < 1e-6
            A = rand(N) + 0.1;
        end

        %% Normalize and quantize A
        A_norm = (A - min(A(:))) / (max(A(:)) - min(A(:)));
        A_discrete = round(A_norm * (n_levels - 1)) / (n_levels - 1);

        %% Map to compliance current range
        Icomp_matrix = Icomp_min + (Icomp_max - Icomp_min) * A_discrete;

        %% Common RRAM parameters
        Rstate = ones(N);                 % all in LRS
        Vreset = -1 * ones(N);            % constant reset voltage

        %% Input vector (voltages ≤ 0.1 V)
        y = rand(N,1) * 0.1;

        %% Assign Rp to base workspace for Simulink model
        assignin('base','Rp',Rp);

        %% ==================== CASE 1: Ideal ====================
        Variability = false;
        RTN = false;

        R = create_rram_array(Rstate, Vreset, Icomp_matrix, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:));
        A_mapped = G ./ G0;

        % Simulate with Simulink model (with parasitic resistance Rp)
        out = sim("RRAM_crossbar_5x5_pr_model.slx");

        % Theoretical and simulated outputs
        x_ideal = inv(A_norm) * y;
        x_sim = out.simout.Data(end, :)';

        % Least-squares scaling
        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        % Compute NRMSE
        nrmse_ideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(r_idx, k, 1) = nrmse_ideal;

        %% ==================== CASE 2: Non-ideal ====================
        Variability = true;
        RTN = true;

        R = create_rram_array(Rstate, Vreset, Icomp_matrix, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:));
        A_mapped = G ./ G0;

        % Simulate with same model
        out = sim("RRAM_crossbar_5x5_pr_model.slx");

        x_sim = out.simout.Data(end, :)';

        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        nrmse_nonideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(r_idx, k, 2) = nrmse_nonideal;

        %% Log progress
        fprintf('Rp=%3d Ω | Run=%d | NRMSE ideal=%.4f | non-ideal=%.4f\n', ...
                Rp, k, nrmse_ideal, nrmse_nonideal);
    end
end

%% ==================== Final Results ====================
mean_ideal = mean(NRMSE_all(:,:,1), 2);
mean_nonideal = mean(NRMSE_all(:,:,2), 2);

fprintf('\n=== Summary of Average NRMSE per Rp ===\n');
for r_idx = 1:length(Rp_values)
    fprintf('Rp = %3d Ω → Ideal = %.4f | Non-ideal = %.4f\n', ...
        Rp_values(r_idx), mean_ideal(r_idx), mean_nonideal(r_idx));
end

%% ==================== Plots ====================
figure;
plot(Rp_values, mean_ideal, '-o', 'LineWidth', 2, 'MarkerSize', 8); hold on;
plot(Rp_values, mean_nonideal, '-s', 'LineWidth', 2, 'MarkerSize', 8);
grid on;
xlabel('Line parasitic resistance Rp [Ω]');
ylabel('Average NRMSE');
title(sprintf('Effect of line parasitic resistances (N=%d, %d-bit encoding, Tech %d)', N, n_bit, Tech_number));
legend('no variability / no RTN', 'with variability + RTN', 'Location', 'northwest');
set(gca, 'FontSize', 12);

%% ==================== Monte Carlo Dispersion Plot ====================
figure;
for r_idx = 1:length(Rp_values)
    plot(Rp_values(r_idx)*ones(1,N_tests), NRMSE_all(r_idx,:,1), 'bo', 'MarkerFaceColor', 'b'); hold on;
    plot(Rp_values(r_idx)*ones(1,N_tests), NRMSE_all(r_idx,:,2), 'rs', 'MarkerFaceColor', 'r');
end
grid on;
xlabel('Line parasitic resistance Rp [Ω]');
ylabel('NRMSE (individual runs)');
title('NRMSE dispersion across Monte Carlo simulations');
legend('Ideal', 'Non-ideal', 'Location', 'northwest');
set(gca, 'FontSize', 12);
