function [R] = create_rram_array(Rstate,Vreset, Icomp, Tech_number,Variability,...
                                 Variability_seed, RTN, RTN_seed)
%create_rram_array create a matrix whose elements are resistive values which 
% depend on the programming voltages, current compliance, RRAM technology, 
% and can include the effects of cycle-to-cycle variability and RTN 
%   Output:
%     * R <= output matrix containing the resistances of the devices in the crossbar array
%   Inputs:
%     * Rstate => Matrix of the same size as R, where 1 means device in LRS, 0 means device in HRS
%     * Vreset => Matrix of the same size as R, indicating the reset
%                 voltage used to program each device in the array. This parameter determine the HRS resistance where Rstate is = 0
%     * Icomp  => Matrix of the same size as R, indicating the current
%                 compliance voltage used to program each device in the array. This parameter determine the LRS resistance where Rstate is = 0
%     * Tech_number => a number from 1 to 4, which correspond to 4
%                      different RRAM technologies 
%     * Variability => true = variability on, false = variability off
%     * Variability_seed => seed number used to determine the random
%                            numbers for variability. Repeat the simulation with different seed
%                           numbers to assess the effect of variability
%     * RTN => true = RTN on, false = RTN off
%     * RTN_seed => seed number used to determine the random
%                   numbers for RTN. Repeat the simulation with different seed
%                   numbers to assess the effect of RTN

    if nargin  ~= 8
        error("create_rram_array: wrong number of input arguments")
    end
    if sum(Tech_number == 1:4)  ~= 1
        error("create_rram_array: wrong Tech number")
    end

    % Load the relevant technology parameters    
    switch Tech_number
        case 1
            load("Parameters\Tech1_param_model_1_0_3_var_old_calib.mat");
            load("Parameters\tech1_bar_vs_v.mat"); 
            Icnom = 1e-3;    
            if min(Vreset)< -2
                error("create_rram_array: too low reset voltage")
            end
        case 2
            load("Parameters\Tech2_param_model_1_0_3_var_old_calib.mat");
            load("Parameters\tech2_bar_vs_v.mat");  
            Icnom = 2e-4;
            if min(Vreset)< -2.5
                error("create_rram_array: too low reset voltage")
            end    
        case 3
            load("Parameters\Tech3_param_model_1_0_3_var_old_calib.mat");
            load("Parameters\tech3_bar_vs_v.mat");             
            Icnom = 1e-4;
            if min(Vreset)< -3
                error("create_rram_array: too low reset voltage")
            end
        case 4
            load("Parameters\Tech4_param_model_1_0_3_var_old_calib.mat");
            load("Parameters\tech4_bar_vs_v.mat");             
            Icnom = 5e-4;
            if min(Vreset)< -2.5
                error("create_rram_array: too low reset voltage")
            end
    end
    
    [~,id,~]=unique(barrier_voltage(:,2));
    barrier_voltage=barrier_voltage(id,:);
    
    X = zeros(size(Rstate));
    for i = 1:size(Rstate,1)
        for j = 1 : size(Rstate,2)
           X(i,j) = interp1(barrier_voltage(:,2),barrier_voltage(:,1),Vreset(i,j)); 
        end
    end
    
    Icomp(Icomp==0) = Icnom;
    
    Rhrs = s.rho*(s.tox-X)/s.S0 +  s.Rlrs * s.beta * (exp(X/s.l)-1)*exp(s.Ea/(300*8.62e-5));
    Rlrs = 0.5./Icomp;
    Rnom = Rstate .* Rlrs + (1-Rstate) .* Rhrs ;
    
    % Compute the resistive value     
    R = Rnom;

    % Include nonideal effects

    if Variability
        
        % --- Variability calculation on S0 and Rlrs ---
        S0     = s.rho * s.tox ./Rlrs;
        sigmaS = (s.ds/3)*S0/s.S0var;
        rng(Variability_seed)
        S0 = S0 + randn(size(Rlrs)).*sigmaS;
    
        % Avoid negative or zero values in S0
        S0(S0 <= 0) = min(S0(S0 > 0));
    
        Rlrs   = s.rho * s.tox ./S0;
    
        % --- Variability on X ---
        X      = X + randn(size(X)) * (s.dx/3);
        X(X<0) = 0;
    
        % --- Rhrs calculation with variability ---
        denom = s.S0 + randn(size(Rlrs))*s.ds/3;
    
        % Avoid negative or zero denominators
        denom(denom <= 0) = min(denom(denom > 0));
    
        Rhrs   = s.rho*(s.tox-X)./denom + ...
                 s.Rlrs * s.beta * (exp(X/s.l)-1)*exp(s.Ea/(300*8.62e-5));
    
        % --- Final combination LRS/HRS ---
        R   = Rstate .* Rlrs + (1-Rstate) .* Rhrs;
    
        % Last parachute: no resistance <= 0
        R(R <= 0) = 1e3;


    end

    
    if RTN
        
        load("Parameters\RTNParamStruct.mat");    
        rtn.maximum_number_defects = 5;
        
        rng(RTN_seed)        
        M1 = Rstate == 0;
        Vread = 0.1;
        Mndefects = randi(rtn.maximum_number_defects,size(Rstate)); %initialize number of defects for each device
        
        Srtn_hrs = s.S0 * 1e-18;
        Srtn_lrs = S0 * 1e-18;
        t_ox_rtn = s.tox * 1e-9;
        x = X * 1e-9;
      
        % RESET defect update
        N_O     = zeros(size(Rstate));
        N_O     = M1.*x .* Srtn_hrs *rtn.O_ions_density;  % Avg. Number of O Ions in vol. x*S . The max function prevents errors when the barrier becomes slightly negative. 
        N_O(N_O>0.1)    = 0.1;
        n_hrs   = poissrnd(N_O, size(Rstate));                % Number of defects random generation        
        n_hrs(n_hrs > rtn.maximum_number_defects) = rtn.maximum_number_defects;
                
        Erel_O      = rtn.Erel0_O + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Erel_O - rtn.Delta_Erel_O;
        Et_O        = rtn.Et0_O + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Et_O - rtn.Delta_Et_O;

        delta_R_hrs = Rhrs.* exp(randn([size(Rstate),rtn.maximum_number_defects]) * rtn.DeltaR_dist_HRS_std + rtn.DeltaR_dist_HRS_mean);     

        state_hrs = rand([size(Rstate),rtn.maximum_number_defects])>0.5; %random initial state
                       
        for i = 1: size(Rstate,1)
            for j = 1: size(Rstate,2)
                delta_R(i,j,n_hrs(i,j)+1:rtn.maximum_number_defects) = 0;
            end
        end           
        
        % RTN device in LRS
        N_V             = Rstate .* t_ox_rtn *pi .*(rtn.rt^2+2* rtn.rt*sqrt(Srtn_lrs /pi))*  rtn.V_density;        %Avg. Number of O Vacancies in vol. t_ox*pi*(r_t^2+2rcf*r_t)              
        N_V(N_V>0.1)    = 0.1;
        n_lrs   = poissrnd(N_V, size(Rstate));                % Number of defects random generation        
        
        n_lrs(n_lrs > rtn.maximum_number_defects) = rtn.maximum_number_defects;
          
        n1 = floor(n_lrs/2);
        n0 = n_lrs - n1;
       
        Erel_V          = rtn.Erel0_V + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Erel_V - rtn.Delta_Erel_V;
        Et_V            = rtn.Et0_V + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Et_V - rtn.Delta_Et_V;
        delta_R_lrs_V   = Rlrs.* exp(randn([size(Rstate),rtn.maximum_number_defects]) * rtn.DeltaR_dist_LRS_std + log(1/(2+(2*t_ox_rtn*...
                                       repmat(Srtn_lrs,[1,1,rtn.maximum_number_defects]))/((rtn.rt)^3))));     
        state_lrs_V = rand([size(Rstate),rtn.maximum_number_defects])>0.5;
        
        Erel_O          = rtn.Erel0_O + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Erel_O - rtn.Delta_Erel_O;
        Et_O            = rtn.Et0_O + rand([size(Rstate),rtn.maximum_number_defects])*2*rtn.Delta_Et_O - rtn.Delta_Et_O;

        delta_R_lrs_O   = Rlrs.* exp(randn([size(Rstate),rtn.maximum_number_defects]) * rtn.DeltaR_dist_LRS_std + log(1/(2+(2*t_ox_rtn*...
                                    repmat(Srtn_lrs,[1,1,rtn.maximum_number_defects]))/((rtn.rt)^3))));     
        state_lrs_O     = rand([size(Rstate),rtn.maximum_number_defects])>0.5;

        for i = 1: size(Rstate,1)
            for j = 1: size(Rstate,2)
                delta_R_lrs_O(i,j,n0(i,j)+1:rtn.maximum_number_defects) = 0;
                delta_R_lrs_V(i,j,n1(i,j)+1:rtn.maximum_number_defects) = 0;
            end
        end     
                 
        % output computation
        Delta_R = sum(M1 .* delta_R_hrs .* state_hrs +...
                  Rstate .* delta_R_lrs_O .* state_lrs_O +... 
                  Rstate .* delta_R_lrs_V .* state_lrs_V, 3); % Cumulative resistance variation due to defects
        R = R + Delta_R;        
        
    end
            
end

