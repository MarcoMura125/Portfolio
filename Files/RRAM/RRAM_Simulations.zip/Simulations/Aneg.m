clc; clear; close all;

%% General parameters
N = 5;                     
N_tests = 20;              % number of Monte Carlo runs
Tech_number = 1;           
Variability_seed = 42;     % base seed for variability
RTN_seed = 7;              % base seed for RTN

%% Simscape parameters
R0 = 1e4;   % reference value for Simulink

%% Encoding parameters
bit_list = 2:7;                              % bit range to simulate
Icomp_min = 1e-5;                           
Icomp_max = 1e-3;                           

%% Results matrix
% Rows: bit value, Cols: test index, Depth: 1 = ideal, 2 = non-ideal
NRMSE_all = zeros(length(bit_list), N_tests, 2);

%% Main simulation loop over bit depth
for b_idx = 1:length(bit_list)
    n_bit = bit_list(b_idx);
    n_levels = 2^n_bit;

    fprintf('\n=== Simulating for %d-bit encoding (A with + and - elements) ===\n', n_bit);

    %% Monte Carlo loop
    for k = 1:N_tests

        rng(1000 + b_idx*100 + k);

        %% --- 1. Generate invertible matrix with positive and negative elements ---
        A = 2*rand(N) - 1 + 0.1;  % values in [-1, 1] (slightly shifted)
        while abs(det(A)) < 1e-6
            A = 2*rand(N) - 1 + 0.1;
        end

        %% --- 2. Split into A+ and A- components ---
        A_plus  = (abs(A) + A) / 2;
        A_minus = (abs(A) - A) / 2;

        %% --- 3. Normalize each part to [0,1] ---
        Aplus_norm  = (A_plus  - min(A_plus(:)))  / (max(A_plus(:))  - min(A_plus(:)) + eps);
        Aminus_norm = (A_minus - min(A_minus(:))) / (max(A_minus(:)) - min(A_minus(:)) + eps);

        %% --- 4. Quantize with n_bit ---
        Aplus_discrete  = round(Aplus_norm  * (n_levels - 1)) / (n_levels - 1);
        Aminus_discrete = round(Aminus_norm * (n_levels - 1)) / (n_levels - 1);

        %% --- 5. Map to compliance currents ---
        Icomp_plus  = Icomp_min + (Icomp_max - Icomp_min) * Aplus_discrete;
        Icomp_minus = Icomp_min + (Icomp_max - Icomp_min) * Aminus_discrete;

        %% --- 6. Combine into N x 2N matrix (alternate columns: A+, A-) ---
        Icomp_combined = zeros(N, 2*N);
        for c = 1:N
            Icomp_combined(:, 2*c - 1) = Icomp_plus(:, c);   % odd columns → A+
            Icomp_combined(:, 2*c)     = Icomp_minus(:, c);  % even columns → A-
        end

        %% --- 7. Input vector (voltages ≤ 0.1 V) ---
        y = rand(N,1) * 0.1;

        %% --- Common parameters for RRAM programming ---
        Rstate = ones(N, 2*N);
        Vreset = -1 * ones(N, 2*N);

        %% --- CASE 1: Ideal (no variability, no RTN) ---
        Variability = false;
        RTN = false;

        R = create_rram_array(Rstate, Vreset, Icomp_combined, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:));

        % Separate conductance matrices
        G_plus  = G(:, 1:2:end);
        G_minus = G(:, 2:2:end);
        A_mapped = (G_plus - G_minus) / G0;

        % Run appropriate Simulink model (must support 2N columns)

        out = sim("RRAM_crossbar_5x5_Aneg_model.slx");


        x_ideal = inv(A) * y;
        x_sim = out.simout.Data(end, :)';

        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        nrmse_ideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(b_idx, k, 1) = nrmse_ideal;

        %% --- CASE 2: Non-ideal (with variability and RTN) ---
        Variability = true;
        RTN = true;

        R = create_rram_array(Rstate, Vreset, Icomp_combined, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:));

        G_plus  = G(:, 1:2:end);
        G_minus = G(:, 2:2:end);
        A_mapped = (G_plus - G_minus) / G0;


        out = sim("RRAM_crossbar_5x5_Aneg_model.slx");


        x_sim = out.simout.Data(end, :)';
        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        nrmse_nonideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(b_idx, k, 2) = nrmse_nonideal;

        fprintf('Bit=%d, Run=%d: NRMSE ideal=%.4f, non-ideal=%.4f\n', ...
                n_bit, k, nrmse_ideal, nrmse_nonideal);
    end
end

%% Final results
disp('=== Summary of NRMSE results (A with + and - elements) ===');
mean_ideal = zeros(1, length(bit_list));
mean_nonideal = zeros(1, length(bit_list));

for b_idx = 1:length(bit_list)
    mean_ideal(b_idx) = mean(NRMSE_all(b_idx,:,1));
    mean_nonideal(b_idx) = mean(NRMSE_all(b_idx,:,2));
    fprintf('Bits = %d: Avg NRMSE ideal = %.4f | non-ideal = %.4f\n', ...
        bit_list(b_idx), mean_ideal(b_idx), mean_nonideal(b_idx));
end

%% --- Plot results ---
figure;
plot(bit_list, mean_ideal, '-o', 'LineWidth', 2, 'MarkerSize', 8); hold on;
plot(bit_list, mean_nonideal, '-s', 'LineWidth', 2, 'MarkerSize', 8);
grid on;
ylim([0 1.2]);
xlabel('Number of bits');
ylabel('Average NRMSE');
title(sprintf('NRMSE vs Bit depth (A with positive & negative elements) - Tech %d', Tech_number));
legend('Ideal (no variability / no RTN)', 'Non-ideal (with variability + RTN)', ...
       'Location', 'northeast');
set(gca, 'FontSize', 12);

%% --- Optional: plot also individual runs ---
figure;
for b_idx = 1:length(bit_list)
    plot(bit_list(b_idx)*ones(1,N_tests), NRMSE_all(b_idx,:,1), 'bo', 'MarkerFaceColor', 'b'); hold on;
    plot(bit_list(b_idx)*ones(1,N_tests), NRMSE_all(b_idx,:,2), 'rs', 'MarkerFaceColor', 'r');
end
grid on;
xlabel('Number of bits');
ylabel('NRMSE (individual runs)');
title('NRMSE dispersion across Monte Carlo simulations (A with + and - elements)');
legend('Ideal', 'Non-ideal', 'Location', 'northwest');
set(gca, 'FontSize', 12);
