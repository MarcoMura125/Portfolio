clc; clear; close all;

%% General parameters
N = 5;                     
N_tests = 20;              % number of Monte Carlo runs
Tech_number = 1;           
Variability_seed = 42;     % base seed for variability
RTN_seed = 7;              % base seed for RTN

%% Simscape parameters
R0 = 1e4;   % reference value for Simulink

%% Encoding parameters
bit_list = 2:7;                              % bit range to simulate
Icomp_min = 1e-5;                           
Icomp_max = 1e-3;                           

%% Results matrix
% Rows: bit value, Cols: test index, Depth: 1 = ideal, 2 = non-ideal
NRMSE_all = zeros(length(bit_list), N_tests, 2);

%% Main simulation loop over bit depth
for b_idx = 1:length(bit_list)
    n_bit = bit_list(b_idx);
    n_levels = 2^n_bit;

    fprintf('\n=== Simulating for %d-bit encoding ===\n', n_bit);

    %% Monte Carlo loop
    for k = 1:N_tests

        rng(1000 + b_idx*100 + k);

        % Generate invertible matrix
        A = rand(N) + 0.1;
        while abs(det(A)) < 1e-6
            A = rand(N) + 0.1;
        end

        % Normalize A to [0,1]
        A_norm = (A - min(A(:))) / (max(A(:)) - min(A(:)));

        % Quantization with n_bit
        A_discrete = round(A_norm * (n_levels-1)) / (n_levels-1);

        % Linear mapping to Icomp range
        Icomp_matrix = Icomp_min + (Icomp_max - Icomp_min) * A_discrete;

        % Input vector (voltages ≤ 0.1 V)
        y = rand(N,1)*0.1;

        %% Common parameters for RRAM programming
        Rstate = ones(N);                 % all set to LRS (to use Icomp)
        Vreset = -1 * ones(N);            % constant reset voltage

        %% --- CASE 1: Ideal (no variability, no RTN)
        Variability = false;
        RTN = false;
        R = create_rram_array(Rstate, Vreset, Icomp_matrix, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:)); 
        A_mapped = G ./ G0;

        if (N==5)
            out = sim("RRAM_crossbar_5x5_model.slx");
        elseif (N==7)
            out = sim("RRAM_crossbar_7x7_model.slx");
        end

        x_ideal = inv(A_norm)*y;
        x_sim = out.simout.Data(end, :)';

        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        nrmse_ideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(b_idx, k, 1) = nrmse_ideal;

        %% --- CASE 2: Non-ideal (with variability and RTN)
        Variability = true;
        RTN = true;
        R = create_rram_array(Rstate, Vreset, Icomp_matrix, ...
            Tech_number, Variability, Variability_seed + k, RTN, RTN_seed);

        G = 1 ./ R;
        G0 = max(G(:)); 
        A_mapped = G ./ G0;

        if (N==5)
            out = sim("RRAM_crossbar_5x5_model.slx");
        elseif (N==7)
            out = sim("RRAM_crossbar_7x7_model.slx");
        end

        x_sim = out.simout.Data(end, :)';

        alpha = (x_sim' * x_ideal) / (x_sim' * x_sim);
        x_rescaled = alpha * x_sim;

        nrmse_nonideal = norm(x_rescaled - x_ideal) / norm(x_ideal);
        NRMSE_all(b_idx, k, 2) = nrmse_nonideal;

        fprintf('Bit=%d, Run=%d: NRMSE ideal=%.4f, non-ideal=%.4f\n', ...
                n_bit, k, nrmse_ideal, nrmse_nonideal);
    end
end

%% Final results
disp('=== Summary of NRMSE results ===');
mean_ideal = zeros(1,length(bit_list));
mean_nonideal = zeros(1,length(bit_list));

for b_idx = 1:length(bit_list)
    mean_ideal(b_idx) = mean(NRMSE_all(b_idx,:,1));
    mean_nonideal(b_idx) = mean(NRMSE_all(b_idx,:,2));
    fprintf('Bits = %d: Avg NRMSE ideal = %.4f | non-ideal = %.4f\n', ...
        bit_list(b_idx), mean_ideal(b_idx), mean_nonideal(b_idx));
end

%% --- Plot results ---
figure;
plot(bit_list, mean_ideal, '-o', 'LineWidth', 2, 'MarkerSize', 8); hold on;
plot(bit_list, mean_nonideal, '-s', 'LineWidth', 2, 'MarkerSize', 8);
grid on;
ylim([0 1.2]); 
xlabel('Number of bits');
ylabel('Average NRMSE');
title(sprintf('NRMSE vs Bit depth, Tech %d', Tech_number));
legend('Ideal (no variability / no RTN)', 'Non-ideal (with variability + RTN)', ...
       'Location', 'northeast');
set(gca, 'FontSize', 12);

%% Optional: plot also individual runs (for visualization of spread)
figure;
for b_idx = 1:length(bit_list)
    plot(bit_list(b_idx)*ones(1,N_tests), NRMSE_all(b_idx,:,1), 'bo', 'MarkerFaceColor', 'b'); hold on;
    plot(bit_list(b_idx)*ones(1,N_tests), NRMSE_all(b_idx,:,2), 'rs', 'MarkerFaceColor', 'r');
end
axis(0,1)
grid on;
xlabel('Number of bits');
ylabel('NRMSE (individual runs)');
title('NRMSE dispersion across Monte Carlo simulations');
legend('Ideal', 'Non-ideal', 'Location', 'northwest');
set(gca, 'FontSize', 12);
